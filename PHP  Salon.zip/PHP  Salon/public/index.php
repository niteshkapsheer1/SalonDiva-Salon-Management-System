<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
if (current_user()) {
    header('Location: dashboard.php');
    exit;
}
$error = isset($_GET['error']) ? 'Sign-in failed. Check your credentials or try again later.' : '';
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SalonDiva · Staff sign in</title>
<style>
:root{--pink:#ffb0c4;--cream:#fff6ec;--crimson:#c8264f;--ink:#2b1520;--muted:#6e4a57}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:1rem;background:linear-gradient(135deg,#ffc2d1,#ff93b0);font:16px/1.5 Outfit,system-ui,sans-serif;color:var(--ink)}
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap');
.card{width:min(100%,440px);background:var(--cream);padding:2rem;border-radius:30px;box-shadow:0 18px 45px #7e24431c}.logo{font-size:1.7rem;font-weight:700;color:var(--crimson)}h1{margin:.4rem 0;font-size:2rem}.muted{color:var(--muted)}label{display:block;font-weight:600;font-size:.9rem;margin:.9rem 0 .35rem}input{width:100%;height:49px;border:1.5px solid #f0d5c4;border-radius:15px;padding:0 1rem;font:inherit}button{width:100%;margin-top:1.2rem;height:52px;border:0;border-radius:999px;background:var(--ink);color:white;font:600 1rem inherit;cursor:pointer}.error{background:#f8dce3;color:#a41e42;border-radius:12px;padding:.7rem}.foot{font-size:.85rem;margin-top:1rem}
</style></head><body><main class="card">
<div class="logo">SalonDiva</div><h1>Welcome back</h1><p class="muted">Sign in to your staff workspace.</p>
<?php if ($error): ?><p class="error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<form method="post" action="login.php">
<input type="hidden" name="_csrf" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
<label for="username">Username or email</label><input id="username" name="username" autocomplete="username" required>
<label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required>
<button type="submit">Sign in securely →</button>
</form><p class="foot muted">Access is assigned by your salon administrator. Public registration is disabled.</p>
</main></body></html>
